import { User } from '@supabase/supabase-js';
import { supabase } from '../lib/supabaseClient';
import { Comentario, Publicacion, ResultadoAuth, Usuario } from '../types/social';

/**
 * Servicio de integración con Supabase para Speaking.
 * Gestiona toda la autenticación (Supabase Auth) y las operaciones
 * de lectura/escritura de publicaciones en la tabla `posts`.
 */

const TABLA_POSTS = 'posts';

/** Convierte un usuario de Supabase Auth al modelo interno `Usuario` */
export function mapearUsuarioSupabase(user: User): Usuario {
  const metadata = (user.user_metadata ?? {}) as Record<string, unknown>;
  const correo = user.email ?? '';
  const nombreRespaldo = correo.split('@')[0] || 'Usuario';

  return {
    id: user.id,
    nombre:
      typeof metadata.full_name === 'string' && metadata.full_name.trim()
        ? metadata.full_name.trim()
        : nombreRespaldo,
    correo,
    avatar: typeof metadata.avatar_url === 'string' ? metadata.avatar_url : '',
    biografia:
      typeof metadata.bio === 'string'
        ? metadata.bio
        : 'Hola, acabo de unirme a Speaking.',
    creadoEn: user.created_at ?? new Date().toISOString(),
  };
}

/** Convierte una fila cruda de la tabla `posts` en una `Publicacion` tipada */
function mapearFilaPost(fila: Record<string, unknown>): Publicacion {
  const likesCrudos = Array.isArray(fila.likes) ? fila.likes : [];
  const comentariosCrudos = Array.isArray(fila.comments) ? fila.comments : [];

  const comentarios: Comentario[] = comentariosCrudos
    .filter((item): item is Record<string, unknown> => Boolean(item && typeof item === 'object'))
    .map((c) => ({
      id: String(c.id ?? `com-${Date.now()}`),
      autorId: String(c.autorId ?? c.author_id ?? ''),
      autorNombre: String(c.autorNombre ?? c.author_name ?? 'Usuario'),
      autorAvatar: String(c.autorAvatar ?? c.author_avatar ?? ''),
      texto: String(c.texto ?? c.text ?? ''),
      creadoEn: String(c.creadoEn ?? c.created_at ?? new Date().toISOString()),
    }));

  return {
    id: String(fila.id),
    autorId: String(fila.user_id ?? ''),
    autorNombre: String(fila.author_name ?? 'Usuario de Speaking'),
    autorCorreo: String(fila.author_email ?? ''),
    autorAvatar: String(fila.author_avatar ?? ''),
    autorBiografia: String(fila.author_bio ?? ''),
    contenido: String(fila.content ?? ''),
    imagen:
      typeof fila.image_url === 'string' && fila.image_url.trim()
        ? fila.image_url
        : undefined,
    meGustaIds: likesCrudos.map((id) => String(id)),
    comentarios,
    creadoEn: String(fila.created_at ?? new Date().toISOString()),
  };
}

/** Obtiene la sesión activa desde Supabase Auth */
export async function obtenerSesionSupabase(): Promise<Usuario | null> {
  if (!supabase) return null;
  const { data, error } = await supabase.auth.getSession();
  if (error || !data.session?.user) return null;
  return mapearUsuarioSupabase(data.session.user);
}

/** Escucha en tiempo real cambios en la sesión de Supabase Auth */
export function suscribirCambioSesion(
  callback: (usuario: Usuario | null) => void
): () => void {
  if (!supabase) return () => {};
  const {
    data: { subscription },
  } = supabase.auth.onAuthStateChange((_evento, session) => {
    callback(session?.user ? mapearUsuarioSupabase(session.user) : null);
  });
  return () => subscription.unsubscribe();
}

/** Inicia sesión con correo y contraseña mediante Supabase Auth */
export async function iniciarSesionSupabase(
  correo: string,
  contrasena: string
): Promise<ResultadoAuth> {
  if (!supabase) {
    return {
      exito: false,
      error: 'Faltan las variables de entorno VITE_SUPABASE_URL y VITE_SUPABASE_ANON_KEY.',
    };
  }

  const emailLimpio = correo.trim().toLowerCase();
  if (!emailLimpio || !contrasena) {
    return { exito: false, error: 'Ingresa tu correo electrónico y tu contraseña.' };
  }

  const { data, error } = await supabase.auth.signInWithPassword({
    email: emailLimpio,
    password: contrasena,
  });

  if (error) {
    const mensaje = error.message.toLowerCase();
    if (mensaje.includes('invalid login credentials')) {
      return { exito: false, error: 'Correo o contraseña incorrectos.' };
    }
    if (mensaje.includes('email not confirmed')) {
      return {
        exito: false,
        error: 'Debes confirmar tu correo electrónico antes de iniciar sesión.',
      };
    }
    return { exito: false, error: error.message };
  }

  if (!data.user) {
    return { exito: false, error: 'No se pudo obtener la sesión del usuario.' };
  }

  return { exito: true, usuario: mapearUsuarioSupabase(data.user) };
}

/** Registra una nueva cuenta en Supabase Auth guardando nombre, biografía y avatar en metadata */
export async function registrarUsuarioSupabase(params: {
  nombre: string;
  correo: string;
  contrasena: string;
}): Promise<ResultadoAuth> {
  if (!supabase) {
    return {
      exito: false,
      error: 'Faltan las variables de entorno VITE_SUPABASE_URL y VITE_SUPABASE_ANON_KEY.',
    };
  }

  const nombre = params.nombre.trim();
  const correo = params.correo.trim().toLowerCase();
  const contrasena = params.contrasena;

  if (nombre.length < 2) {
    return { exito: false, error: 'Escribe tu nombre completo (mínimo 2 caracteres).' };
  }
  if (!correo.includes('@')) {
    return { exito: false, error: 'Ingresa un correo electrónico válido.' };
  }
  if (contrasena.length < 6) {
    return { exito: false, error: 'La contraseña debe tener al menos 6 caracteres.' };
  }

  const { data, error } = await supabase.auth.signUp({
    email: correo,
    password: contrasena,
    options: {
      data: {
        full_name: nombre,
        avatar_url: '',
        bio: 'Hola, acabo de unirme a Speaking.',
      },
    },
  });

  if (error) {
    return { exito: false, error: error.message };
  }

  // Si Supabase requiere confirmación por correo, `data.session` vendrá nulo
  if (data.user && !data.session) {
    return {
      exito: true,
      mensajeInfo:
        'Cuenta creada. Revisa tu bandeja de entrada para confirmar tu correo e iniciar sesión.',
    };
  }

  if (!data.user) {
    return { exito: false, error: 'No se pudo completar el registro.' };
  }

  return { exito: true, usuario: mapearUsuarioSupabase(data.user) };
}

/** Cierra la sesión activa en Supabase Auth */
export async function cerrarSesionSupabase(): Promise<void> {
  if (!supabase) return;
  await supabase.auth.signOut();
}

/**
 * Actualiza los metadatos del perfil en Supabase Auth y sincroniza
 * los datos del autor en sus publicaciones existentes de la tabla `posts`.
 */
export async function actualizarPerfilSupabase(
  usuarioId: string,
  cambios: { nombre: string; biografia: string; avatar: string }
): Promise<Usuario> {
  if (!supabase) {
    throw new Error('Supabase no está configurado.');
  }

  const nombre = cambios.nombre.trim();
  const biografia = cambios.biografia.trim();
  const avatar = cambios.avatar.trim();

  const { data, error } = await supabase.auth.updateUser({
    data: {
      full_name: nombre,
      bio: biografia,
      avatar_url: avatar,
    },
  });

  if (error || !data.user) {
    throw new Error(error?.message ?? 'No se pudo actualizar el perfil.');
  }

  // Actualizar la información visible del autor en sus publicaciones previas
  await supabase
    .from(TABLA_POSTS)
    .update({
      author_name: nombre,
      author_avatar: avatar,
      author_bio: biografia,
    })
    .eq('user_id', usuarioId);

  return mapearUsuarioSupabase(data.user);
}

/** Lee todas las publicaciones de la tabla `posts` ordenadas cronológicamente */
export async function obtenerPublicacionesSupabase(): Promise<Publicacion[]> {
  if (!supabase) return [];

  const { data, error } = await supabase
    .from(TABLA_POSTS)
    .select('*')
    .order('created_at', { ascending: false });

  if (error) {
    throw new Error(`Error al leer publicaciones: ${error.message}`);
  }

  return (data ?? []).map((fila) => mapearFilaPost(fila as Record<string, unknown>));
}

/** Inserta una nueva publicación en la tabla `posts` */
export async function crearPublicacionSupabase(params: {
  usuario: Usuario;
  contenido: string;
  imagen?: string;
}): Promise<Publicacion> {
  if (!supabase) {
    throw new Error('Supabase no está configurado.');
  }

  const { data, error } = await supabase
    .from(TABLA_POSTS)
    .insert({
      user_id: params.usuario.id,
      author_name: params.usuario.nombre,
      author_email: params.usuario.correo,
      author_avatar: params.usuario.avatar,
      author_bio: params.usuario.biografia,
      content: params.contenido.trim(),
      image_url: params.imagen?.trim() || null,
      likes: [],
      comments: [],
    })
    .select('*')
    .single();

  if (error || !data) {
    throw new Error(error?.message ?? 'No se pudo guardar la publicación en Supabase.');
  }

  return mapearFilaPost(data as Record<string, unknown>);
}

/** Elimina una publicación de la tabla `posts` */
export async function eliminarPublicacionSupabase(publicacionId: string): Promise<void> {
  if (!supabase) {
    throw new Error('Supabase no está configurado.');
  }

  const { error } = await supabase.from(TABLA_POSTS).delete().eq('id', publicacionId);
  if (error) {
    throw new Error(error.message);
  }
}

/** Actualiza el arreglo `likes` de una publicación en la tabla `posts` */
export async function alternarMeGustaSupabase(
  publicacionId: string,
  meGustaActuales: string[],
  usuarioId: string
): Promise<string[]> {
  if (!supabase) {
    throw new Error('Supabase no está configurado.');
  }

  const yaDioMeGusta = meGustaActuales.includes(usuarioId);
  const nuevosLikes = yaDioMeGusta
    ? meGustaActuales.filter((id) => id !== usuarioId)
    : [...meGustaActuales, usuarioId];

  const { error } = await supabase
    .from(TABLA_POSTS)
    .update({ likes: nuevosLikes })
    .eq('id', publicacionId);

  if (error) {
    throw new Error(error.message);
  }

  return nuevosLikes;
}

/** Agrega un comentario al arreglo `comments` de una publicación en la tabla `posts` */
export async function agregarComentarioSupabase(
  publicacionId: string,
  comentariosActuales: Comentario[],
  params: { autor: Usuario; texto: string }
): Promise<Comentario[]> {
  if (!supabase) {
    throw new Error('Supabase no está configurado.');
  }

  const nuevoComentario: Comentario = {
    id: `com-${Date.now()}-${Math.random().toString(36).slice(2, 7)}`,
    autorId: params.autor.id,
    autorNombre: params.autor.nombre,
    autorAvatar: params.autor.avatar,
    texto: params.texto.trim(),
    creadoEn: new Date().toISOString(),
  };

  const nuevosComentarios = [...comentariosActuales, nuevoComentario];

  const { error } = await supabase
    .from(TABLA_POSTS)
    .update({ comments: nuevosComentarios })
    .eq('id', publicacionId);

  if (error) {
    throw new Error(error.message);
  }

  return nuevosComentarios;
}

/** Elimina un comentario del arreglo `comments` de una publicación en la tabla `posts` */
export async function eliminarComentarioSupabase(
  publicacionId: string,
  comentariosActuales: Comentario[],
  comentarioId: string
): Promise<Comentario[]> {
  if (!supabase) {
    throw new Error('Supabase no está configurado.');
  }

  const nuevosComentarios = comentariosActuales.filter((c) => c.id !== comentarioId);

  const { error } = await supabase
    .from(TABLA_POSTS)
    .update({ comments: nuevosComentarios })
    .eq('id', publicacionId);

  if (error) {
    throw new Error(error.message);
  }

  return nuevosComentarios;
}
