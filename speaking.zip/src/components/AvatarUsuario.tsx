import { useEffect, useState } from 'react';
import { obtenerIniciales } from '../utils/formatoFecha';

interface AvatarUsuarioProps {
  nombre: string;
  src?: string;
  tamano?: 'sm' | 'md' | 'lg' | 'xl';
  className?: string;
}

/**
 * Muestra la foto de perfil del usuario o sus iniciales como respaldo
 * cuando no hay imagen o si ocurre un error al cargarla.
 */
export function AvatarUsuario({
  nombre,
  src,
  tamano = 'md',
  className = '',
}: AvatarUsuarioProps) {
  const [errorCarga, setErrorCarga] = useState(false);

  // Reiniciar el estado de error si cambia la ruta de la imagen
  useEffect(() => {
    setErrorCarga(false);
  }, [src]);

  const dimensiones: Record<NonNullable<AvatarUsuarioProps['tamano']>, string> = {
    sm: 'w-8 h-8 text-xs',
    md: 'w-10 h-10 text-sm',
    lg: 'w-12 h-12 text-base',
    xl: 'w-24 h-24 text-2xl',
  };

  const mostrarImagen = Boolean(src && src.trim() && !errorCarga);

  if (mostrarImagen) {
    return (
      <img
        src={src}
        alt={`Foto de perfil de ${nombre}`}
        referrerPolicy="no-referrer"
        onError={() => setErrorCarga(true)}
        className={`${dimensiones[tamano]} rounded-full object-cover bg-[#1E1E26] border border-[#2C2C38] shrink-0 ${className}`}
      />
    );
  }

  return (
    <div
      aria-label={`Avatar de ${nombre}`}
      className={`${dimensiones[tamano]} rounded-full bg-violet-950/70 text-violet-200 border border-violet-700/40 font-display font-semibold flex items-center justify-center shrink-0 select-none ${className}`}
    >
      {obtenerIniciales(nombre)}
    </div>
  );
}
