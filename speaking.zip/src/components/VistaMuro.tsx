import { AlertCircle, RefreshCw, Search, User as UserIcon } from 'lucide-react';
import { useMemo, useState } from 'react';
import { Publicacion, Usuario } from '../types/social';
import { formatearArroba } from '../utils/formatoFecha';
import { AvatarUsuario } from './AvatarUsuario';
import { CreadorPublicacion } from './CreadorPublicacion';
import { TarjetaPublicacion } from './TarjetaPublicacion';

interface VistaMuroProps {
  usuarioActual: Usuario;
  publicaciones: Publicacion[];
  cargandoPublicaciones: boolean;
  errorPublicaciones: string | null;
  onRecargarPublicaciones: () => Promise<void>;
  onPublicar: (datos: { contenido: string; imagen?: string }) => Promise<void>;
  onAlternarMeGusta: (publicacionId: string) => Promise<void>;
  onAgregarComentario: (publicacionId: string, texto: string) => Promise<void>;
  onEliminarPublicacion: (publicacionId: string) => Promise<void>;
  onEliminarComentario: (publicacionId: string, comentarioId: string) => Promise<void>;
  onAbrirPerfil: (usuarioId: string) => void;
}

/**
 * Vista principal del muro (Feed) conectado a la tabla `posts` de Supabase.
 */
export function VistaMuro({
  usuarioActual,
  publicaciones,
  cargandoPublicaciones,
  errorPublicaciones,
  onRecargarPublicaciones,
  onPublicar,
  onAlternarMeGusta,
  onAgregarComentario,
  onEliminarPublicacion,
  onEliminarComentario,
  onAbrirPerfil,
}: VistaMuroProps) {
  const [busqueda, setBusqueda] = useState('');
  const [filtro, setFiltro] = useState<'todas' | 'mias'>('todas');

  /** Cantidad de publicaciones creadas por el usuario conectado */
  const cantidadMisPublicaciones = useMemo(
    () => publicaciones.filter((p) => p.autorId === usuarioActual.id).length,
    [publicaciones, usuarioActual.id]
  );

  /** Publicaciones filtradas por pestaña y búsqueda manteniendo orden cronológico */
  const publicacionesFiltradas = useMemo(() => {
    const termino = busqueda.trim().toLowerCase();
    return publicaciones.filter((pub) => {
      if (filtro === 'mias' && pub.autorId !== usuarioActual.id) {
        return false;
      }
      if (!termino) return true;
      const coincideContenido = pub.contenido.toLowerCase().includes(termino);
      const coincideAutor = pub.autorNombre.toLowerCase().includes(termino);
      return coincideContenido || coincideAutor;
    });
  }, [publicaciones, filtro, usuarioActual.id, busqueda]);

  /** Autores recientes descubiertos desde las publicaciones cargadas */
  const personasRecientes = useMemo(() => {
    const vistos = new Set<string>();
    const lista: { id: string; nombre: string; correo: string; avatar: string }[] = [];

    for (const pub of publicaciones) {
      if (!pub.autorId || pub.autorId === usuarioActual.id || vistos.has(pub.autorId)) {
        continue;
      }
      vistos.add(pub.autorId);
      lista.push({
        id: pub.autorId,
        nombre: pub.autorNombre,
        correo: pub.autorCorreo,
        avatar: pub.autorAvatar,
      });
      if (lista.length >= 5) break;
    }

    return lista;
  }, [publicaciones, usuarioActual.id]);

  return (
    <main className="max-w-[1140px] mx-auto px-4 sm:px-6 py-6 sm:py-8">
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-7 items-start">
        {/* Columna lateral izquierda: Resumen del usuario conectado y autores recientes */}
        <aside className="hidden lg:block lg:col-span-4 space-y-5 sticky top-24">
          <section className="bg-[#141419] border border-[#24242E] rounded-2xl p-5 space-y-4">
            <div className="flex items-center gap-3.5">
              <AvatarUsuario
                nombre={usuarioActual.nombre}
                src={usuarioActual.avatar}
                tamano="lg"
              />
              <div className="min-w-0">
                <h2 className="font-display text-base font-semibold text-white truncate">
                  {usuarioActual.nombre}
                </h2>
                <p className="text-xs text-[#8E8E9E] truncate">
                  {formatearArroba(usuarioActual.correo)} ·{' '}
                  <span className="tabular-nums">{cantidadMisPublicaciones}</span>{' '}
                  {cantidadMisPublicaciones === 1 ? 'publicación' : 'publicaciones'}
                </p>
              </div>
            </div>

            <p className="text-sm text-[#B2B2C0] leading-relaxed line-clamp-3">
              {usuarioActual.biografia || 'Sin biografía todavía.'}
            </p>

            <button
              type="button"
              onClick={() => onAbrirPerfil(usuarioActual.id)}
              className="w-full min-h-[40px] px-4 py-2 rounded-xl text-sm font-medium bg-[#1C1C25] hover:bg-[#252531] text-[#F4F4F6] border border-[#2A2A36] transition-colors flex items-center justify-center gap-2 whitespace-nowrap shrink-0 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-violet-500"
            >
              <UserIcon className="w-4 h-4 text-violet-400" aria-hidden="true" />
              <span>Ver y editar perfil</span>
            </button>
          </section>

          {personasRecientes.length > 0 && (
            <section className="bg-[#141419] border border-[#24242E] rounded-2xl p-5 space-y-3.5">
              <h3 className="font-display text-sm font-semibold text-[#F4F4F6]">
                Personas en Speaking
              </h3>
              <ul className="divide-y divide-[#202029]">
                {personasRecientes.map((persona) => (
                  <li key={persona.id} className="py-2.5 first:pt-0 last:pb-0">
                    <button
                      type="button"
                      onClick={() => onAbrirPerfil(persona.id)}
                      className="w-full flex items-center gap-3 text-left group rounded-lg py-1 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-violet-500"
                    >
                      <AvatarUsuario
                        nombre={persona.nombre}
                        src={persona.avatar}
                        tamano="sm"
                      />
                      <div className="min-w-0 flex-1">
                        <p className="text-sm font-medium text-[#E8E8EE] group-hover:text-violet-300 transition-colors truncate">
                          {persona.nombre}
                        </p>
                        <p className="text-xs text-[#8E8E9E] truncate">
                          {formatearArroba(persona.correo || persona.nombre)}
                        </p>
                      </div>
                    </button>
                  </li>
                ))}
              </ul>
            </section>
          )}
        </aside>

        {/* Columna central principal */}
        <section className="lg:col-span-8 max-w-[660px] w-full mx-auto lg:mx-0 space-y-5">
          <CreadorPublicacion usuarioActual={usuarioActual} onPublicar={onPublicar} />

          {/* Barra de filtros y búsqueda */}
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
            <div
              role="tablist"
              aria-label="Filtrar publicaciones"
              className="inline-flex items-center gap-1 p-1 bg-[#141419] border border-[#24242E] rounded-xl self-start"
            >
              <button
                type="button"
                role="tab"
                aria-selected={filtro === 'todas'}
                onClick={() => setFiltro('todas')}
                className={`min-h-[36px] px-3.5 py-1.5 rounded-lg text-xs font-medium transition-colors whitespace-nowrap shrink-0 ${
                  filtro === 'todas'
                    ? 'bg-violet-600 text-white'
                    : 'text-[#9A9AA8] hover:text-white'
                }`}
              >
                Recientes
              </button>
              <button
                type="button"
                role="tab"
                aria-selected={filtro === 'mias'}
                onClick={() => setFiltro('mias')}
                className={`min-h-[36px] px-3.5 py-1.5 rounded-lg text-xs font-medium transition-colors whitespace-nowrap shrink-0 ${
                  filtro === 'mias'
                    ? 'bg-violet-600 text-white'
                    : 'text-[#9A9AA8] hover:text-white'
                }`}
              >
                Mis publicaciones
              </button>
            </div>

            <div className="flex items-center gap-2 flex-1 sm:justify-end">
              <div className="relative flex-1 sm:max-w-[260px]">
                <Search
                  className="w-4 h-4 text-[#7E7E8E] absolute left-3 top-1/2 -translate-y-1/2 pointer-events-none"
                  aria-hidden="true"
                />
                <input
                  type="search"
                  value={busqueda}
                  onChange={(e) => setBusqueda(e.target.value)}
                  placeholder="Buscar en el muro..."
                  aria-label="Buscar publicaciones"
                  className="w-full min-h-[40px] pl-9 pr-3.5 py-2 bg-[#141419] border border-[#24242E] rounded-xl text-sm text-[#F4F4F6] placeholder-[#6E6E7E] focus:outline-none focus:border-violet-500 transition-colors"
                />
              </div>

              <button
                type="button"
                onClick={() => void onRecargarPublicaciones()}
                aria-label="Actualizar publicaciones"
                className="w-10 h-10 rounded-xl bg-[#141419] border border-[#24242E] hover:border-[#343442] text-[#A1A1AF] hover:text-white flex items-center justify-center transition-colors shrink-0 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-violet-500"
              >
                <RefreshCw
                  className={`w-4 h-4 ${cargandoPublicaciones ? 'animate-spin text-violet-400' : ''}`}
                  aria-hidden="true"
                />
              </button>
            </div>
          </div>

          {errorPublicaciones && (
            <div
              role="alert"
              className="bg-rose-950/35 border border-rose-800/60 rounded-2xl p-4 flex items-start justify-between gap-3 text-sm text-rose-200"
            >
              <div className="flex items-start gap-2.5">
                <AlertCircle className="w-4 h-4 text-rose-400 shrink-0 mt-0.5" aria-hidden="true" />
                <span>{errorPublicaciones}</span>
              </div>
              <button
                type="button"
                onClick={() => void onRecargarPublicaciones()}
                className="text-xs font-medium text-white underline underline-offset-2 shrink-0"
              >
                Reintentar
              </button>
            </div>
          )}

          {/* Estado de carga inicial */}
          {cargandoPublicaciones && publicaciones.length === 0 ? (
            <div className="space-y-4">
              {[1, 2].map((n) => (
                <div
                  key={n}
                  className="bg-[#141419] border border-[#24242E] rounded-2xl p-5 space-y-4 animate-pulse"
                >
                  <div className="flex items-center gap-3">
                    <div className="w-10 h-10 rounded-full bg-[#22222B]" />
                    <div className="space-y-2 flex-1">
                      <div className="h-3.5 w-32 bg-[#22222B] rounded" />
                      <div className="h-2.5 w-24 bg-[#1D1D25] rounded" />
                    </div>
                  </div>
                  <div className="space-y-2">
                    <div className="h-3.5 w-full bg-[#22222B] rounded" />
                    <div className="h-3.5 w-3/4 bg-[#1D1D25] rounded" />
                  </div>
                </div>
              ))}
            </div>
          ) : publicacionesFiltradas.length === 0 ? (
            <div className="bg-[#141419] border border-[#24242E] rounded-2xl p-8 text-center space-y-2">
              <p className="text-base font-medium text-[#F4F4F6]">
                No hay publicaciones para mostrar
              </p>
              <p className="text-sm text-[#8E8E9E]">
                {busqueda.trim()
                  ? 'Prueba con otras palabras de búsqueda.'
                  : 'Anímate a escribir la primera publicación en el cuadro de arriba.'}
              </p>
            </div>
          ) : (
            <div className="space-y-4">
              {publicacionesFiltradas.map((publicacion) => (
                <TarjetaPublicacion
                  key={publicacion.id}
                  publicacion={publicacion}
                  usuarioActualId={usuarioActual.id}
                  onAlternarMeGusta={onAlternarMeGusta}
                  onAgregarComentario={onAgregarComentario}
                  onEliminarPublicacion={onEliminarPublicacion}
                  onEliminarComentario={onEliminarComentario}
                  onAbrirPerfil={onAbrirPerfil}
                />
              ))}
            </div>
          )}
        </section>
      </div>
    </main>
  );
}
