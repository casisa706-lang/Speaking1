import { LogOut } from 'lucide-react';
import { VistaActiva } from '../types/social';

interface BarraNavegacionProps {
  vistaActiva: VistaActiva;
  viendoMiPerfil: boolean;
  onIrMuro: () => void;
  onIrMiPerfil: () => void;
  onCerrarSesion: () => void;
}

/**
 * Barra de navegación superior de una sola fila y tres zonas:
 * [Marca Speaking] — [Enlaces de navegación] — [Acción Cerrar sesión]
 */
export function BarraNavegacion({
  vistaActiva,
  viendoMiPerfil,
  onIrMuro,
  onIrMiPerfil,
  onCerrarSesion,
}: BarraNavegacionProps) {
  const enMuro = vistaActiva === 'muro';
  const enPerfilPropio = vistaActiva === 'perfil' && viendoMiPerfil;

  return (
    <header className="sticky top-0 z-30 bg-[#0B0B0E]/90 backdrop-blur-md border-b border-[#1E1E26]">
      <div className="max-w-[1140px] mx-auto px-4 sm:px-6 h-16 flex items-center justify-between gap-8">
        {/* Zona 1: Marca en texto limpio de una sola línea */}
        <button
          type="button"
          onClick={onIrMuro}
          className="font-display text-xl font-bold tracking-tight text-white hover:text-violet-300 transition-colors whitespace-nowrap shrink-0 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-violet-500 rounded-md px-1"
        >
          Speaking
        </button>

        {/* Zona 2: Enlaces de navegación claros y de una línea */}
        <nav aria-label="Navegación principal" className="flex items-center gap-6">
          <button
            type="button"
            onClick={onIrMuro}
            aria-current={enMuro ? 'page' : undefined}
            className={`min-h-[40px] px-1 text-sm font-medium transition-colors whitespace-nowrap shrink-0 border-b-2 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-violet-500 ${
              enMuro
                ? 'text-white border-violet-500'
                : 'text-[#9A9AA8] border-transparent hover:text-[#F4F4F6]'
            }`}
          >
            Inicio
          </button>

          <button
            type="button"
            onClick={onIrMiPerfil}
            aria-current={enPerfilPropio ? 'page' : undefined}
            className={`min-h-[40px] px-1 text-sm font-medium transition-colors whitespace-nowrap shrink-0 border-b-2 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-violet-500 ${
              enPerfilPropio
                ? 'text-white border-violet-500'
                : 'text-[#9A9AA8] border-transparent hover:text-[#F4F4F6]'
            }`}
          >
            Mi perfil
          </button>
        </nav>

        {/* Zona 3: Acción única de cierre de sesión */}
        <div className="flex items-center shrink-0">
          <button
            type="button"
            onClick={onCerrarSesion}
            className="min-h-[40px] px-3.5 py-2 rounded-xl text-sm font-medium text-[#D4D4DD] hover:text-white bg-[#15151C] hover:bg-[#1E1E28] border border-[#262632] transition-colors flex items-center gap-2 whitespace-nowrap shrink-0 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-violet-500"
          >
            <LogOut className="w-4 h-4 text-violet-400" aria-hidden="true" />
            <span className="hidden sm:inline">Cerrar sesión</span>
            <span className="sm:hidden">Salir</span>
          </button>
        </div>
      </div>
    </header>
  );
}
