import { Heart, ImageOff, MessageCircle, Send, Trash2 } from 'lucide-react';
import { FormEvent, useRef, useState } from 'react';
import { Publicacion } from '../types/social';
import { formatearArroba, formatearFechaRelativa } from '../utils/formatoFecha';
import { AvatarUsuario } from './AvatarUsuario';

interface TarjetaPublicacionProps {
  publicacion: Publicacion;
  usuarioActualId: string;
  onAlternarMeGusta: (publicacionId: string) => Promise<void>;
  onAgregarComentario: (publicacionId: string, texto: string) => Promise<void>;
  onEliminarPublicacion: (publicacionId: string) => Promise<void>;
  onEliminarComentario: (publicacionId: string, comentarioId: string) => Promise<void>;
  onAbrirPerfil: (usuarioId: string) => void;
}

/**
 * Tarjeta individual de publicación obtenida desde la tabla `posts` en Supabase.
 */
export function TarjetaPublicacion({
  publicacion,
  usuarioActualId,
  onAlternarMeGusta,
  onAgregarComentario,
  onEliminarPublicacion,
  onEliminarComentario,
  onAbrirPerfil,
}: TarjetaPublicacionProps) {
  const [comentariosAbiertos, setComentariosAbiertos] = useState(
    publicacion.comentarios.length > 0
  );
  const [nuevoComentario, setNuevoComentario] = useState('');
  const [enviandoComentario, setEnviandoComentario] = useState(false);
  const [confirmarEliminar, setConfirmarEliminar] = useState(false);
  const [errorImagen, setErrorImagen] = useState(false);

  const inputComentarioRef = useRef<HTMLInputElement>(null);

  const nombreAutor = publicacion.autorNombre || 'Usuario de Speaking';
  const arrobaAutor = formatearArroba(publicacion.autorCorreo || nombreAutor);
  const esPropia = publicacion.autorId === usuarioActualId;
  const yaDioMeGusta = publicacion.meGustaIds.includes(usuarioActualId);
  const totalMeGusta = publicacion.meGustaIds.length;
  const totalComentarios = publicacion.comentarios.length;

  /** Abre la sección de comentarios y enfoca el campo de texto */
  const manejarClickComentar = () => {
    setComentariosAbiertos(true);
    setTimeout(() => {
      inputComentarioRef.current?.focus();
    }, 40);
  };

  /** Envía un comentario nuevo a Supabase */
  const manejarEnvioComentario = async (evento: FormEvent) => {
    evento.preventDefault();
    const limpio = nuevoComentario.trim();
    if (!limpio || enviandoComentario) return;

    setEnviandoComentario(true);
    try {
      await onAgregarComentario(publicacion.id, limpio);
      setNuevoComentario('');
      setComentariosAbiertos(true);
    } finally {
      setEnviandoComentario(false);
    }
  };

  return (
    <article className="bg-[#141419] border border-[#24242E] rounded-2xl p-4 sm:p-5 space-y-4">
      <header className="flex items-start justify-between gap-3">
        <div className="flex items-center gap-3 min-w-0">
          <button
            type="button"
            onClick={() => publicacion.autorId && onAbrirPerfil(publicacion.autorId)}
            className="shrink-0 rounded-full focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-violet-500"
            aria-label={`Ver perfil de ${nombreAutor}`}
          >
            <AvatarUsuario nombre={nombreAutor} src={publicacion.autorAvatar} tamano="md" />
          </button>

          <div className="min-w-0">
            <button
              type="button"
              onClick={() => publicacion.autorId && onAbrirPerfil(publicacion.autorId)}
              className="block text-[15px] font-semibold text-[#F4F4F6] hover:text-violet-300 transition-colors truncate max-w-full text-left focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-violet-500 rounded"
            >
              {nombreAutor}
            </button>
            <div className="flex items-center gap-1.5 text-xs text-[#8E8E9E] truncate">
              <span className="truncate">{arrobaAutor}</span>
              <span aria-hidden="true">·</span>
              <time dateTime={publicacion.creadoEn} className="whitespace-nowrap">
                {formatearFechaRelativa(publicacion.creadoEn)}
              </time>
            </div>
          </div>
        </div>

        {esPropia && (
          <div className="shrink-0 flex items-center gap-1.5">
            {confirmarEliminar ? (
              <>
                <button
                  type="button"
                  onClick={() => void onEliminarPublicacion(publicacion.id)}
                  className="min-h-[36px] px-3 py-1 rounded-lg text-xs font-medium bg-rose-600/90 hover:bg-rose-600 text-white transition-colors whitespace-nowrap shrink-0"
                >
                  Confirmar
                </button>
                <button
                  type="button"
                  onClick={() => setConfirmarEliminar(false)}
                  className="min-h-[36px] px-2.5 py-1 rounded-lg text-xs text-[#9A9AA8] hover:text-white transition-colors whitespace-nowrap shrink-0"
                >
                  Cancelar
                </button>
              </>
            ) : (
              <button
                type="button"
                onClick={() => setConfirmarEliminar(true)}
                aria-label="Eliminar publicación"
                className="w-9 h-9 rounded-xl flex items-center justify-center text-[#7E7E8E] hover:text-rose-300 hover:bg-[#1E1E26] transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-violet-500"
              >
                <Trash2 className="w-4 h-4" aria-hidden="true" />
              </button>
            )}
          </div>
        )}
      </header>

      {publicacion.contenido && (
        <p className="text-[15px] leading-relaxed text-[#E6E6EE] whitespace-pre-wrap break-words">
          {publicacion.contenido}
        </p>
      )}

      {publicacion.imagen && (
        <div className="rounded-xl overflow-hidden bg-[#0E0E12] border border-[#22222B]">
          {errorImagen ? (
            <div className="py-10 px-4 flex flex-col items-center justify-center gap-2 text-[#7E7E8E]">
              <ImageOff className="w-6 h-6" aria-hidden="true" />
              <span className="text-xs">No se pudo mostrar la imagen adjunta</span>
            </div>
          ) : (
            <img
              src={publicacion.imagen}
              alt={`Imagen compartida por ${nombreAutor}`}
              referrerPolicy="no-referrer"
              onError={() => setErrorImagen(true)}
              className="w-full max-h-[460px] object-cover block"
            />
          )}
        </div>
      )}

      <div className="flex items-center gap-3 pt-2 border-t border-[#202029]">
        <button
          type="button"
          onClick={() => void onAlternarMeGusta(publicacion.id)}
          aria-pressed={yaDioMeGusta}
          className={`min-h-[40px] px-3.5 py-2 rounded-xl text-sm font-medium transition-colors flex items-center gap-2 whitespace-nowrap shrink-0 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-violet-500 ${
            yaDioMeGusta
              ? 'bg-violet-600/15 text-violet-300'
              : 'text-[#A1A1AF] hover:text-white hover:bg-[#1C1C24]'
          }`}
        >
          <Heart
            className={`w-4 h-4 transition-transform ${
              yaDioMeGusta ? 'fill-violet-400 text-violet-400 scale-110' : ''
            }`}
            aria-hidden="true"
          />
          <span>Me gusta</span>
          <span className="tabular-nums text-xs opacity-80">{totalMeGusta}</span>
        </button>

        <button
          type="button"
          onClick={manejarClickComentar}
          className="min-h-[40px] px-3.5 py-2 rounded-xl text-sm font-medium text-[#A1A1AF] hover:text-white hover:bg-[#1C1C24] transition-colors flex items-center gap-2 whitespace-nowrap shrink-0 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-violet-500"
        >
          <MessageCircle className="w-4 h-4" aria-hidden="true" />
          <span>Comentar</span>
          <span className="tabular-nums text-xs opacity-80">{totalComentarios}</span>
        </button>
      </div>

      {comentariosAbiertos && (
        <section
          aria-label="Comentarios"
          className="pt-3 border-t border-[#202029] space-y-3.5"
        >
          {publicacion.comentarios.length > 0 && (
            <ul className="space-y-3">
              {publicacion.comentarios.map((comentario) => {
                const esMio = comentario.autorId === usuarioActualId;

                return (
                  <li key={comentario.id} className="flex items-start gap-2.5">
                    <button
                      type="button"
                      onClick={() => comentario.autorId && onAbrirPerfil(comentario.autorId)}
                      className="shrink-0 rounded-full mt-0.5 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-violet-500"
                      aria-label={`Ver perfil de ${comentario.autorNombre}`}
                    >
                      <AvatarUsuario
                        nombre={comentario.autorNombre}
                        src={comentario.autorAvatar}
                        tamano="sm"
                      />
                    </button>

                    <div className="flex-1 min-w-0">
                      <div className="flex items-baseline justify-between gap-2">
                        <div className="flex items-baseline gap-2 min-w-0">
                          <button
                            type="button"
                            onClick={() =>
                              comentario.autorId && onAbrirPerfil(comentario.autorId)
                            }
                            className="text-xs font-semibold text-[#F4F4F6] hover:text-violet-300 transition-colors truncate"
                          >
                            {comentario.autorNombre}
                          </button>
                          <span className="text-[11px] text-[#7E7E8E] whitespace-nowrap">
                            {formatearFechaRelativa(comentario.creadoEn)}
                          </span>
                        </div>

                        {esMio && (
                          <button
                            type="button"
                            onClick={() =>
                              void onEliminarComentario(publicacion.id, comentario.id)
                            }
                            aria-label="Eliminar comentario"
                            className="text-[11px] text-[#7E7E8E] hover:text-rose-300 transition-colors shrink-0"
                          >
                            Eliminar
                          </button>
                        )}
                      </div>
                      <p className="text-sm text-[#D6D6E0] leading-snug break-words mt-0.5">
                        {comentario.texto}
                      </p>
                    </div>
                  </li>
                );
              })}
            </ul>
          )}

          <form onSubmit={manejarEnvioComentario} className="flex items-center gap-2 pt-1">
            <input
              ref={inputComentarioRef}
              type="text"
              value={nuevoComentario}
              onChange={(e) => setNuevoComentario(e.target.value)}
              placeholder="Escribe un comentario..."
              aria-label="Escribe un comentario"
              className="flex-1 min-h-[40px] px-3.5 py-2 bg-[#0E0E12] border border-[#262632] rounded-xl text-sm text-[#F4F4F6] placeholder-[#6E6E7E] focus:outline-none focus:border-violet-500 transition-colors"
            />
            <button
              type="submit"
              disabled={!nuevoComentario.trim() || enviandoComentario}
              aria-label="Enviar comentario"
              className="min-h-[40px] px-3.5 py-2 rounded-xl bg-violet-600 hover:bg-violet-500 disabled:bg-[#22222C] disabled:text-[#6B6B7A] disabled:cursor-not-allowed text-white text-sm font-medium transition-colors flex items-center gap-1.5 whitespace-nowrap shrink-0 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-violet-400"
            >
              <Send className="w-3.5 h-3.5" aria-hidden="true" />
              <span className="hidden sm:inline">Enviar</span>
            </button>
          </form>
        </section>
      )}
    </article>
  );
}
