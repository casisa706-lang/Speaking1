import {
  AlertCircle,
  ArrowRight,
  CheckCircle2,
  Eye,
  EyeOff,
  Image as ImageIcon,
  MessageSquare,
  Users,
} from 'lucide-react';
import { FormEvent, useState } from 'react';
import { estaSupabaseConfigurado } from '../lib/supabaseClient';
import { ResultadoAuth } from '../types/social';

interface PantallaAccesoProps {
  onIniciarSesion: (correo: string, contrasena: string) => Promise<ResultadoAuth>;
  onRegistrar: (datos: {
    nombre: string;
    correo: string;
    contrasena: string;
  }) => Promise<ResultadoAuth>;
}

/**
 * Pantalla inicial de bienvenida, inicio de sesión y registro con Supabase Auth.
 */
export function PantallaAcceso({ onIniciarSesion, onRegistrar }: PantallaAccesoProps) {
  const [modo, setModo] = useState<'login' | 'registro'>('login');
  const [nombre, setNombre] = useState('');
  const [correo, setCorreo] = useState('');
  const [contrasena, setContrasena] = useState('');
  const [mostrarContrasena, setMostrarContrasena] = useState(false);
  const [cargando, setCargando] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [mensajeInfo, setMensajeInfo] = useState<string | null>(null);

  /** Cambia entre el formulario de ingreso y el de registro */
  const cambiarModo = (nuevoModo: 'login' | 'registro') => {
    setModo(nuevoModo);
    setError(null);
    setMensajeInfo(null);
  };

  /** Procesa el envío del formulario contra Supabase Auth */
  const manejarEnvio = async (evento: FormEvent) => {
    evento.preventDefault();
    setError(null);
    setMensajeInfo(null);
    setCargando(true);

    try {
      if (modo === 'login') {
        const resultado = await onIniciarSesion(correo, contrasena);
        if (!resultado.exito && resultado.error) {
          setError(resultado.error);
        }
        return;
      }

      const resultado = await onRegistrar({ nombre, correo, contrasena });
      if (!resultado.exito && resultado.error) {
        setError(resultado.error);
      } else if (resultado.mensajeInfo) {
        setMensajeInfo(resultado.mensajeInfo);
        setModo('login');
      }
    } finally {
      setCargando(false);
    }
  };

  return (
    <div className="min-h-screen bg-[#0B0B0E] text-[#F4F4F6] flex flex-col justify-center px-4 py-10 sm:px-8">
      <div className="w-full max-w-[1060px] mx-auto grid grid-cols-1 lg:grid-cols-12 gap-10 lg:gap-14 items-center">
        {/* Columna izquierda: Presentación sobria de la red social */}
        <section className="lg:col-span-6 space-y-8">
          <div className="space-y-4">
            <h1 className="font-display text-4xl sm:text-5xl font-bold tracking-tight text-white">
              Speaking
            </h1>
            <p className="text-lg sm:text-xl text-[#B4B4C0] leading-relaxed max-w-lg">
              Un espacio tranquilo para compartir ideas, fotos y conversar con tu comunidad sin ruido visual ni distracciones.
            </p>
          </div>

          <div className="space-y-5 pt-2 border-t border-[#1F1F27] max-w-md">
            <div className="flex items-start gap-3.5 pt-2">
              <MessageSquare className="w-5 h-5 text-violet-400 shrink-0 mt-0.5" aria-hidden="true" />
              <div>
                <h2 className="text-sm font-semibold text-[#F4F4F6]">Muro cronológico directo</h2>
                <p className="text-sm text-[#8E8E9E] leading-relaxed">
                  Lee publicaciones en el orden en que ocurren, reacciona con un toque y deja comentarios al instante.
                </p>
              </div>
            </div>

            <div className="flex items-start gap-3.5">
              <ImageIcon className="w-5 h-5 text-violet-400 shrink-0 mt-0.5" aria-hidden="true" />
              <div>
                <h2 className="text-sm font-semibold text-[#F4F4F6]">Texto e imágenes sin complicaciones</h2>
                <p className="text-sm text-[#8E8E9E] leading-relaxed">
                  Publica tus pensamientos o comparte fotografías desde tu dispositivo o mediante un enlace.
                </p>
              </div>
            </div>

            <div className="flex items-start gap-3.5">
              <Users className="w-5 h-5 text-violet-400 shrink-0 mt-0.5" aria-hidden="true" />
              <div>
                <h2 className="text-sm font-semibold text-[#F4F4F6]">Perfil personalizable</h2>
                <p className="text-sm text-[#8E8E9E] leading-relaxed">
                  Edita tu nombre, foto y biografía en cualquier momento y consulta todas tus publicaciones.
                </p>
              </div>
            </div>
          </div>
        </section>

        {/* Columna derecha: Tarjeta única de acceso y registro */}
        <section className="lg:col-span-6 w-full max-w-[460px] mx-auto lg:ml-auto">
          <div className="bg-[#141419] border border-[#24242E] rounded-2xl p-6 sm:p-8 shadow-xl shadow-black/30">
            {!estaSupabaseConfigurado && (
              <div
                role="alert"
                className="mb-5 flex items-start gap-2.5 px-3.5 py-3 rounded-xl bg-amber-950/40 border border-amber-800/60 text-xs text-amber-200 leading-relaxed"
              >
                <AlertCircle className="w-4 h-4 text-amber-400 shrink-0 mt-0.5" aria-hidden="true" />
                <span>
                  Configura <strong>VITE_SUPABASE_URL</strong> y{' '}
                  <strong>VITE_SUPABASE_ANON_KEY</strong> en las variables de entorno para activar la autenticación y el muro.
                </span>
              </div>
            )}

            {/* Selector de pestañas Iniciar sesión / Crear cuenta */}
            <div
              role="tablist"
              aria-label="Opciones de acceso"
              className="grid grid-cols-2 gap-1 p-1 bg-[#0E0E12] border border-[#22222B] rounded-xl mb-6"
            >
              <button
                type="button"
                role="tab"
                aria-selected={modo === 'login'}
                onClick={() => cambiarModo('login')}
                className={`min-h-[40px] px-4 py-2 text-sm font-medium rounded-lg transition-colors whitespace-nowrap shrink-0 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-violet-500 ${
                  modo === 'login'
                    ? 'bg-violet-600 text-white'
                    : 'text-[#9A9AA8] hover:text-[#F4F4F6]'
                }`}
              >
                Iniciar sesión
              </button>
              <button
                type="button"
                role="tab"
                aria-selected={modo === 'registro'}
                onClick={() => cambiarModo('registro')}
                className={`min-h-[40px] px-4 py-2 text-sm font-medium rounded-lg transition-colors whitespace-nowrap shrink-0 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-violet-500 ${
                  modo === 'registro'
                    ? 'bg-violet-600 text-white'
                    : 'text-[#9A9AA8] hover:text-[#F4F4F6]'
                }`}
              >
                Crear cuenta
              </button>
            </div>

            <form onSubmit={manejarEnvio} className="space-y-4" noValidate>
              {modo === 'registro' && (
                <div>
                  <label htmlFor="campo-nombre" className="block text-sm font-medium text-[#D4D4DD] mb-1.5">
                    Nombre completo
                  </label>
                  <input
                    id="campo-nombre"
                    type="text"
                    value={nombre}
                    onChange={(e) => setNombre(e.target.value)}
                    placeholder="Ej. Laura Méndez"
                    autoComplete="name"
                    className="w-full min-h-[44px] px-3.5 py-2.5 bg-[#0E0E12] border border-[#282834] rounded-xl text-[15px] text-[#F4F4F6] placeholder-[#686878] focus:outline-none focus:border-violet-500 focus:ring-1 focus:ring-violet-500 transition-colors"
                  />
                </div>
              )}

              <div>
                <label htmlFor="campo-correo" className="block text-sm font-medium text-[#D4D4DD] mb-1.5">
                  Correo electrónico
                </label>
                <input
                  id="campo-correo"
                  type="email"
                  value={correo}
                  onChange={(e) => setCorreo(e.target.value)}
                  placeholder="tucorreo@ejemplo.com"
                  autoComplete="email"
                  className="w-full min-h-[44px] px-3.5 py-2.5 bg-[#0E0E12] border border-[#282834] rounded-xl text-[15px] text-[#F4F4F6] placeholder-[#686878] focus:outline-none focus:border-violet-500 focus:ring-1 focus:ring-violet-500 transition-colors"
                />
              </div>

              <div>
                <label htmlFor="campo-contrasena" className="block text-sm font-medium text-[#D4D4DD] mb-1.5">
                  Contraseña
                </label>
                <div className="relative">
                  <input
                    id="campo-contrasena"
                    type={mostrarContrasena ? 'text' : 'password'}
                    value={contrasena}
                    onChange={(e) => setContrasena(e.target.value)}
                    placeholder={modo === 'registro' ? 'Mínimo 6 caracteres' : 'Tu contraseña'}
                    autoComplete={modo === 'registro' ? 'new-password' : 'current-password'}
                    className="w-full min-h-[44px] pl-3.5 pr-11 py-2.5 bg-[#0E0E12] border border-[#282834] rounded-xl text-[15px] text-[#F4F4F6] placeholder-[#686878] focus:outline-none focus:border-violet-500 focus:ring-1 focus:ring-violet-500 transition-colors"
                  />
                  <button
                    type="button"
                    onClick={() => setMostrarContrasena((prev) => !prev)}
                    aria-label={mostrarContrasena ? 'Ocultar contraseña' : 'Mostrar contraseña'}
                    className="absolute right-2 top-1/2 -translate-y-1/2 w-8 h-8 flex items-center justify-center text-[#8E8E9E] hover:text-[#F4F4F6] rounded-lg focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-violet-500"
                  >
                    {mostrarContrasena ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                  </button>
                </div>
              </div>

              {mensajeInfo && (
                <div
                  role="status"
                  className="flex items-start gap-2.5 px-3.5 py-2.5 rounded-xl bg-violet-950/40 border border-violet-700/60 text-sm text-violet-200"
                >
                  <CheckCircle2 className="w-4 h-4 text-violet-400 shrink-0 mt-0.5" aria-hidden="true" />
                  <span>{mensajeInfo}</span>
                </div>
              )}

              {error && (
                <div
                  role="alert"
                  className="flex items-start gap-2.5 px-3.5 py-2.5 rounded-xl bg-rose-950/40 border border-rose-800/60 text-sm text-rose-200"
                >
                  <AlertCircle className="w-4 h-4 text-rose-400 shrink-0 mt-0.5" aria-hidden="true" />
                  <span>{error}</span>
                </div>
              )}

              <button
                type="submit"
                disabled={cargando}
                className="w-full min-h-[44px] px-5 py-2.5 bg-violet-600 hover:bg-violet-500 disabled:bg-[#23232E] disabled:text-[#6B6B7A] active:bg-violet-700 text-white font-medium text-[15px] rounded-xl transition-colors flex items-center justify-center gap-2 whitespace-nowrap shrink-0 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-violet-400 focus-visible:ring-offset-2 focus-visible:ring-offset-[#141419]"
              >
                <span>
                  {cargando
                    ? 'Procesando...'
                    : modo === 'login'
                      ? 'Entrar a Speaking'
                      : 'Crear mi cuenta'}
                </span>
                <ArrowRight className="w-4 h-4" aria-hidden="true" />
              </button>
            </form>
          </div>
        </section>
      </div>
    </div>
  );
}
