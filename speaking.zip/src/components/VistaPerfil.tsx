import { AlertCircle, ArrowLeft, Check, ImagePlus, Pencil, X } from 'lucide-react';
import { ChangeEvent, FormEvent, useEffect, useMemo, useRef, useState } from 'react';
import { Publicacion, Usuario } from '../types/social';
import { formatearArroba } from '../utils/formatoFecha';
import { AVATARES_PREDEFINIDOS, procesarImagenArchivo } from '../utils/procesarImagen';
import { AvatarUsuario } from './AvatarUsuario';
import { CreadorPublicacion } from './CreadorPublicacion';
import { TarjetaPublicacion } from './TarjetaPublicacion';

interface VistaPerfilProps {
  usuarioVisto: Usuario;
  usuarioActual: Usuario;
  publicaciones: Publicacion[];
  onVolverMuro: () => void;
  onActualizarPerfil: (datos: {
    nombre: string;
    biografia: string;
    avatar: string;
  }) => Promise<void>;
  onPublicar: (datos: { contenido: string; imagen?: string }) => Promise<void>;
  onAlternarMeGusta: (publicacionId: string) => Promise<void>;
  onAgregarComentario: (publicacionId: string, texto: string) => Promise<void>;
  onEliminarPublicacion: (publicacionId: string) => Promise<void>;
  onEliminarComentario: (publicacionId: string, comentarioId: string) => Promise<void>;
  onAbrirPerfil: (usuarioId: string) => void;
}

/**
 * Vista de perfil de usuario conectada a Supabase Auth y la tabla `posts`.
 */
export function VistaPerfil({
  usuarioVisto,
  usuarioActual,
  publicaciones,
  onVolverMuro,
  onActualizarPerfil,
  onPublicar,
  onAlternarMeGusta,
  onAgregarComentario,
  onEliminarPublicacion,
  onEliminarComentario,
  onAbrirPerfil,
}: VistaPerfilProps) {
  const esMiPerfil = usuarioVisto.id === usuarioActual.id;

  const [editando, setEditando] = useState(false);
  const [nombre, setNombre] = useState(usuarioVisto.nombre);
  const [biografia, setBiografia] = useState(usuarioVisto.biografia);
  const [avatar, setAvatar] = useState(usuarioVisto.avatar);
  const [guardando, setGuardando] = useState(false);
  const [errorPerfil, setErrorPerfil] = useState<string | null>(null);
  const [mensajeGuardado, setMensajeGuardado] = useState(false);

  const inputAvatarRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    setEditando(false);
    setNombre(usuarioVisto.nombre);
    setBiografia(usuarioVisto.biografia);
    setAvatar(usuarioVisto.avatar);
    setErrorPerfil(null);
    setMensajeGuardado(false);
  }, [usuarioVisto]);

  /** Publicaciones exclusivas del usuario mostrado en este perfil */
  const publicacionesDelUsuario = useMemo(
    () => publicaciones.filter((p) => p.autorId === usuarioVisto.id),
    [publicaciones, usuarioVisto.id]
  );

  /** Procesa una foto de avatar seleccionada desde el dispositivo */
  const manejarSubidaAvatar = async (evento: ChangeEvent<HTMLInputElement>) => {
    const archivo = evento.target.files?.[0];
    if (!archivo) return;
    setErrorPerfil(null);
    try {
      const dataUrl = await procesarImagenArchivo(archivo, 480);
      setAvatar(dataUrl);
    } catch (err) {
      setErrorPerfil(
        err instanceof Error ? err.message : 'No se pudo procesar la foto.'
      );
    } finally {
      if (inputAvatarRef.current) {
        inputAvatarRef.current.value = '';
      }
    }
  };

  /** Guarda los cambios del perfil en Supabase Auth y sus publicaciones */
  const manejarGuardar = async (evento: FormEvent) => {
    evento.preventDefault();
    if (!nombre.trim() || guardando) return;

    setGuardando(true);
    setErrorPerfil(null);
    try {
      await onActualizarPerfil({
        nombre: nombre.trim(),
        biografia: biografia.trim(),
        avatar: avatar.trim(),
      });
      setEditando(false);
      setMensajeGuardado(true);
      setTimeout(() => setMensajeGuardado(false), 3000);
    } catch (err) {
      setErrorPerfil(
        err instanceof Error ? err.message : 'No se pudieron guardar los cambios.'
      );
    } finally {
      setGuardando(false);
    }
  };

  return (
    <main className="max-w-[760px] mx-auto px-4 sm:px-6 py-6 sm:py-8 space-y-6">
      <button
        type="button"
        onClick={onVolverMuro}
        className="min-h-[40px] inline-flex items-center gap-2 text-sm font-medium text-[#A1A1AF] hover:text-white transition-colors rounded-lg focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-violet-500"
      >
        <ArrowLeft className="w-4 h-4 text-violet-400" aria-hidden="true" />
        <span>Volver al muro</span>
      </button>

      <section className="bg-[#141419] border border-[#24242E] rounded-2xl p-6 sm:p-7">
        {!editando ? (
          <div className="space-y-5">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
              <div className="flex items-center gap-4 min-w-0">
                <AvatarUsuario
                  nombre={usuarioVisto.nombre}
                  src={usuarioVisto.avatar}
                  tamano="xl"
                />
                <div className="min-w-0 space-y-1">
                  <h1 className="font-display text-2xl font-bold text-white truncate">
                    {usuarioVisto.nombre}
                  </h1>
                  <p className="text-sm text-[#8E8E9E] truncate">
                    {formatearArroba(usuarioVisto.correo || usuarioVisto.nombre)} ·{' '}
                    <span className="tabular-nums">{publicacionesDelUsuario.length}</span>{' '}
                    {publicacionesDelUsuario.length === 1 ? 'publicación' : 'publicaciones'}
                  </p>
                </div>
              </div>

              {esMiPerfil && (
                <button
                  type="button"
                  onClick={() => setEditando(true)}
                  className="min-h-[40px] px-4 py-2 rounded-xl text-sm font-medium bg-violet-600 hover:bg-violet-500 text-white transition-colors inline-flex items-center justify-center gap-2 whitespace-nowrap shrink-0 self-start sm:self-center focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-violet-400"
                >
                  <Pencil className="w-4 h-4" aria-hidden="true" />
                  <span>Editar perfil</span>
                </button>
              )}
            </div>

            <div className="pt-4 border-t border-[#202029]">
              <h2 className="text-xs font-medium text-[#8E8E9E] mb-1.5">Biografía</h2>
              <p className="text-[15px] leading-relaxed text-[#E2E2EC] whitespace-pre-wrap">
                {usuarioVisto.biografia || 'Este usuario aún no ha escrito una biografía.'}
              </p>
            </div>

            {mensajeGuardado && (
              <div
                role="status"
                className="flex items-center gap-2 text-sm text-violet-300 pt-1"
              >
                <Check className="w-4 h-4" aria-hidden="true" />
                <span>Tu perfil se actualizó correctamente.</span>
              </div>
            )}
          </div>
        ) : (
          <form onSubmit={manejarGuardar} className="space-y-5">
            <div className="flex items-center justify-between gap-4 pb-3 border-b border-[#202029]">
              <h1 className="font-display text-lg font-semibold text-white">
                Editar información de perfil
              </h1>
              <button
                type="button"
                onClick={() => setEditando(false)}
                aria-label="Cancelar edición"
                className="w-9 h-9 rounded-xl flex items-center justify-center text-[#8E8E9E] hover:text-white hover:bg-[#1E1E26] transition-colors"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <div className="space-y-3">
              <span className="block text-sm font-medium text-[#D4D4DD]">
                Foto o avatar
              </span>
              <div className="flex flex-wrap items-center gap-4">
                <AvatarUsuario nombre={nombre || usuarioVisto.nombre} src={avatar} tamano="xl" />

                <div className="flex-1 min-w-[220px] space-y-3">
                  <div className="flex flex-wrap items-center gap-2">
                    <input
                      ref={inputAvatarRef}
                      type="file"
                      accept="image/*"
                      onChange={manejarSubidaAvatar}
                      className="hidden"
                    />
                    <button
                      type="button"
                      onClick={() => inputAvatarRef.current?.click()}
                      className="min-h-[40px] px-3.5 py-2 rounded-xl text-xs font-medium bg-[#1D1D26] hover:bg-[#262632] text-[#F4F4F6] border border-[#2C2C3A] transition-colors inline-flex items-center gap-2 whitespace-nowrap shrink-0"
                    >
                      <ImagePlus className="w-4 h-4 text-violet-400" aria-hidden="true" />
                      <span>Subir foto</span>
                    </button>

                    {avatar && (
                      <button
                        type="button"
                        onClick={() => setAvatar('')}
                        className="min-h-[40px] px-3 py-2 rounded-xl text-xs text-[#9A9AA8] hover:text-white transition-colors whitespace-nowrap shrink-0"
                      >
                        Usar iniciales
                      </button>
                    )}
                  </div>

                  <div className="flex items-center gap-2">
                    <span className="text-xs text-[#8E8E9E]">Sugeridos:</span>
                    {AVATARES_PREDEFINIDOS.map((opcion) => (
                      <button
                        key={opcion.ruta}
                        type="button"
                        onClick={() => setAvatar(opcion.ruta)}
                        title={opcion.etiqueta}
                        className={`rounded-full p-0.5 transition-transform hover:scale-105 ${
                          avatar === opcion.ruta
                            ? 'ring-2 ring-violet-500'
                            : 'opacity-80 hover:opacity-100'
                        }`}
                      >
                        <AvatarUsuario nombre={opcion.etiqueta} src={opcion.ruta} tamano="sm" />
                      </button>
                    ))}
                  </div>
                </div>
              </div>

              <input
                type="url"
                value={avatar.startsWith('data:') ? '' : avatar}
                onChange={(e) => setAvatar(e.target.value)}
                placeholder="O pega el enlace directo de una foto (https://...)"
                aria-label="Enlace de foto de perfil"
                className="w-full min-h-[42px] px-3.5 py-2 bg-[#0E0E12] border border-[#282834] rounded-xl text-sm text-[#F4F4F6] placeholder-[#686878] focus:outline-none focus:border-violet-500"
              />
            </div>

            <div>
              <label htmlFor="perfil-nombre" className="block text-sm font-medium text-[#D4D4DD] mb-1.5">
                Nombre
              </label>
              <input
                id="perfil-nombre"
                type="text"
                required
                value={nombre}
                onChange={(e) => setNombre(e.target.value)}
                className="w-full min-h-[44px] px-3.5 py-2.5 bg-[#0E0E12] border border-[#282834] rounded-xl text-[15px] text-[#F4F4F6] focus:outline-none focus:border-violet-500"
              />
            </div>

            <div>
              <label htmlFor="perfil-bio" className="block text-sm font-medium text-[#D4D4DD] mb-1.5">
                Biografía
              </label>
              <textarea
                id="perfil-bio"
                rows={3}
                value={biografia}
                onChange={(e) => setBiografia(e.target.value)}
                placeholder="Cuéntale brevemente a la comunidad sobre ti..."
                className="w-full px-3.5 py-2.5 bg-[#0E0E12] border border-[#282834] rounded-xl text-[15px] leading-relaxed text-[#F4F4F6] placeholder-[#686878] focus:outline-none focus:border-violet-500 resize-none"
              />
            </div>

            {errorPerfil && (
              <div
                role="alert"
                className="flex items-center gap-2 px-3 py-2 rounded-xl bg-rose-950/40 border border-rose-800/60 text-xs text-rose-200"
              >
                <AlertCircle className="w-4 h-4 text-rose-400 shrink-0" aria-hidden="true" />
                <span>{errorPerfil}</span>
              </div>
            )}

            <div className="flex items-center justify-end gap-3 pt-2">
              <button
                type="button"
                onClick={() => setEditando(false)}
                className="min-h-[40px] px-4 py-2 rounded-xl text-sm font-medium text-[#A1A1AF] hover:text-white hover:bg-[#1E1E26] transition-colors whitespace-nowrap shrink-0"
              >
                Cancelar
              </button>
              <button
                type="submit"
                disabled={!nombre.trim() || guardando}
                className="min-h-[40px] px-5 py-2 rounded-xl text-sm font-medium bg-violet-600 hover:bg-violet-500 disabled:bg-[#23232E] disabled:text-[#6B6B7A] text-white transition-colors whitespace-nowrap shrink-0 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-violet-400"
              >
                {guardando ? 'Guardando...' : 'Guardar cambios'}
              </button>
            </div>
          </form>
        )}
      </section>

      {esMiPerfil && (
        <CreadorPublicacion usuarioActual={usuarioActual} onPublicar={onPublicar} />
      )}

      <section className="space-y-4">
        <h2 className="font-display text-base font-semibold text-[#F4F4F6]">
          {esMiPerfil ? 'Tus publicaciones' : `Publicaciones de ${usuarioVisto.nombre}`}
        </h2>

        {publicacionesDelUsuario.length === 0 ? (
          <div className="bg-[#141419] border border-[#24242E] rounded-2xl p-8 text-center space-y-2">
            <p className="text-base font-medium text-[#F4F4F6]">
              Aún no hay publicaciones aquí
            </p>
            <p className="text-sm text-[#8E8E9E]">
              {esMiPerfil
                ? 'Comparte tu primer mensaje o fotografía desde el cuadro superior.'
                : 'Este usuario todavía no ha publicado en Speaking.'}
            </p>
          </div>
        ) : (
          <div className="space-y-4">
            {publicacionesDelUsuario.map((publicacion) => (
              <TarjetaPublicacion
                key={publicacion.id}
                publicacion={publicacion}
                usuarioActualId={usuarioActual.id}
                onAlternarMeGusta={onAlternarMeGusta}
                onAgregarComentario={onAgregarComentario}
                onEliminarPublicacion={onEliminarPublicacion}
                onEliminarComentario={onEliminarComentario}
                onAbrirPerfil={onAbrirPerfil}
              />
            ))}
          </div>
        )}
      </section>
    </main>
  );
}
