import { AlertCircle, ImagePlus, Link2, Send, X } from 'lucide-react';
import { ChangeEvent, FormEvent, useRef, useState } from 'react';
import { Usuario } from '../types/social';
import { procesarImagenArchivo } from '../utils/procesarImagen';
import { AvatarUsuario } from './AvatarUsuario';

interface CreadorPublicacionProps {
  usuarioActual: Usuario;
  onPublicar: (datos: { contenido: string; imagen?: string }) => Promise<void>;
}

/**
 * Tarjeta para redactar una nueva publicación de texto y/o imagen en Supabase.
 */
export function CreadorPublicacion({ usuarioActual, onPublicar }: CreadorPublicacionProps) {
  const [contenido, setContenido] = useState('');
  const [imagen, setImagen] = useState('');
  const [mostrarCampoUrl, setMostrarCampoUrl] = useState(false);
  const [urlTemporal, setUrlTemporal] = useState('');
  const [procesandoImagen, setProcesandoImagen] = useState(false);
  const [publicando, setPublicando] = useState(false);
  const [errorImagen, setErrorImagen] = useState<string | null>(null);

  const inputArchivoRef = useRef<HTMLInputElement>(null);

  const primerNombre = usuarioActual.nombre.split(' ')[0];
  const puedePublicar =
    Boolean(contenido.trim() || imagen.trim()) && !procesandoImagen && !publicando;

  /** Maneja la selección y compresión de una imagen desde el dispositivo */
  const manejarArchivo = async (evento: ChangeEvent<HTMLInputElement>) => {
    const archivo = evento.target.files?.[0];
    if (!archivo) return;

    setErrorImagen(null);
    setProcesandoImagen(true);
    try {
      const dataUrl = await procesarImagenArchivo(archivo);
      setImagen(dataUrl);
      setMostrarCampoUrl(false);
      setUrlTemporal('');
    } catch (err) {
      setErrorImagen(
        err instanceof Error ? err.message : 'No pudimos cargar esa imagen.'
      );
    } finally {
      setProcesandoImagen(false);
      if (inputArchivoRef.current) {
        inputArchivoRef.current.value = '';
      }
    }
  };

  /** Aplica un enlace de imagen externo ingresado manualmente */
  const aplicarUrlImagen = () => {
    const limpia = urlTemporal.trim();
    if (!limpia) return;
    setErrorImagen(null);
    setImagen(limpia);
    setMostrarCampoUrl(false);
  };

  /** Limpia la imagen adjunta */
  const quitarImagen = () => {
    setImagen('');
    setUrlTemporal('');
    setErrorImagen(null);
  };

  /** Envía la publicación a Supabase y reinicia el formulario */
  const manejarEnvio = async (evento: FormEvent) => {
    evento.preventDefault();
    if (!puedePublicar) return;

    setPublicando(true);
    setErrorImagen(null);
    try {
      await onPublicar({
        contenido: contenido.trim(),
        imagen: imagen.trim() || undefined,
      });

      setContenido('');
      setImagen('');
      setUrlTemporal('');
      setMostrarCampoUrl(false);
    } catch (err) {
      setErrorImagen(
        err instanceof Error ? err.message : 'No se pudo publicar en este momento.'
      );
    } finally {
      setPublicando(false);
    }
  };

  return (
    <form
      onSubmit={manejarEnvio}
      className="bg-[#141419] border border-[#24242E] rounded-2xl p-4 sm:p-5 space-y-4"
    >
      <div className="flex items-start gap-3.5">
        <AvatarUsuario nombre={usuarioActual.nombre} src={usuarioActual.avatar} tamano="md" />
        <div className="flex-1 min-w-0">
          <label htmlFor="texto-nueva-publicacion" className="sr-only">
            Escribe una publicación
          </label>
          <textarea
            id="texto-nueva-publicacion"
            rows={3}
            value={contenido}
            onChange={(e) => setContenido(e.target.value)}
            placeholder={`¿Qué quieres compartir hoy, ${primerNombre}?`}
            className="w-full resize-none bg-transparent text-[15px] leading-relaxed text-[#F4F4F6] placeholder-[#727282] focus:outline-none"
          />
        </div>
      </div>

      {mostrarCampoUrl && !imagen && (
        <div className="flex flex-col sm:flex-row gap-2 pt-1">
          <input
            type="url"
            value={urlTemporal}
            onChange={(e) => setUrlTemporal(e.target.value)}
            placeholder="https://ejemplo.com/foto.jpg"
            aria-label="Enlace de imagen"
            className="flex-1 min-h-[40px] px-3.5 py-2 bg-[#0E0E12] border border-[#282834] rounded-xl text-sm text-[#F4F4F6] placeholder-[#686878] focus:outline-none focus:border-violet-500"
          />
          <div className="flex items-center gap-2 shrink-0">
            <button
              type="button"
              onClick={aplicarUrlImagen}
              className="min-h-[40px] px-4 py-2 rounded-xl text-sm font-medium bg-[#22222E] hover:bg-[#2B2B3A] text-[#F4F4F6] transition-colors whitespace-nowrap shrink-0"
            >
              Adjuntar
            </button>
            <button
              type="button"
              onClick={() => setMostrarCampoUrl(false)}
              className="min-h-[40px] px-3 py-2 rounded-xl text-sm text-[#8E8E9E] hover:text-[#F4F4F6] transition-colors whitespace-nowrap shrink-0"
            >
              Cancelar
            </button>
          </div>
        </div>
      )}

      {imagen && (
        <div className="relative rounded-xl overflow-hidden bg-[#0E0E12] border border-[#24242E]">
          <img
            src={imagen}
            alt="Vista previa de la imagen adjunta"
            referrerPolicy="no-referrer"
            onError={() => {
              setErrorImagen('No se pudo cargar la imagen desde ese enlace.');
              setImagen('');
            }}
            className="w-full max-h-80 object-cover block"
          />
          <button
            type="button"
            onClick={quitarImagen}
            aria-label="Quitar imagen adjunta"
            className="absolute top-3 right-3 w-9 h-9 rounded-full bg-black/75 hover:bg-black text-white flex items-center justify-center border border-white/15 transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-violet-400"
          >
            <X className="w-4 h-4" />
          </button>
        </div>
      )}

      {errorImagen && (
        <div
          role="alert"
          className="flex items-center gap-2 px-3 py-2 rounded-xl bg-rose-950/40 border border-rose-800/60 text-xs text-rose-200"
        >
          <AlertCircle className="w-4 h-4 text-rose-400 shrink-0" aria-hidden="true" />
          <span>{errorImagen}</span>
        </div>
      )}

      <div className="flex flex-wrap items-center justify-between gap-3 pt-3 border-t border-[#202029]">
        <div className="flex items-center gap-2">
          <input
            ref={inputArchivoRef}
            type="file"
            accept="image/*"
            onChange={manejarArchivo}
            className="hidden"
          />
          <button
            type="button"
            disabled={procesandoImagen || publicando}
            onClick={() => inputArchivoRef.current?.click()}
            className="min-h-[40px] px-3.5 py-2 rounded-xl text-sm font-medium text-[#C4C4D0] hover:text-white hover:bg-[#1C1C24] transition-colors flex items-center gap-2 whitespace-nowrap shrink-0 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-violet-500"
          >
            <ImagePlus className="w-4 h-4 text-violet-400" aria-hidden="true" />
            <span>{procesandoImagen ? 'Procesando...' : 'Subir foto'}</span>
          </button>

          <button
            type="button"
            disabled={publicando}
            onClick={() => setMostrarCampoUrl((prev) => !prev)}
            className="min-h-[40px] px-3.5 py-2 rounded-xl text-sm font-medium text-[#C4C4D0] hover:text-white hover:bg-[#1C1C24] transition-colors flex items-center gap-2 whitespace-nowrap shrink-0 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-violet-500"
          >
            <Link2 className="w-4 h-4 text-violet-400" aria-hidden="true" />
            <span>Enlace</span>
          </button>
        </div>

        <button
          type="submit"
          disabled={!puedePublicar}
          className="min-h-[40px] px-5 py-2 rounded-xl text-sm font-medium bg-violet-600 hover:bg-violet-500 disabled:bg-[#23232E] disabled:text-[#6B6B7A] disabled:cursor-not-allowed text-white transition-colors flex items-center gap-2 whitespace-nowrap shrink-0 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-violet-400"
        >
          <Send className="w-4 h-4" aria-hidden="true" />
          <span>{publicando ? 'Publicando...' : 'Publicar'}</span>
        </button>
      </div>
    </form>
  );
}
