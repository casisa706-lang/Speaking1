/**
 * Avatares sugeridos locales disponibles como opción rápida en el perfil.
 */
export const AVATARES_PREDEFINIDOS: { etiqueta: string; ruta: string }[] = [
  {
    etiqueta: 'Retrato 1',
    ruta: '/src/assets/images/avatar_sofia_1795409469638.jpg',
  },
  {
    etiqueta: 'Retrato 2',
    ruta: '/src/assets/images/avatar_mateo_1795409469227.jpg',
  },
  {
    etiqueta: 'Retrato 3',
    ruta: '/src/assets/images/avatar_camila_1795409469156.jpg',
  },
];

/**
 * Redimensiona y comprime una imagen subida desde el dispositivo del usuario
 * para adjuntarla de forma ligera en publicaciones o avatares.
 */
export function procesarImagenArchivo(archivo: File, anchoMaximo = 960): Promise<string> {
  return new Promise((resolve, reject) => {
    if (!archivo.type.startsWith('image/')) {
      reject(new Error('Selecciona un archivo de imagen válido (JPG, PNG o WebP).'));
      return;
    }

    const lector = new FileReader();
    lector.onerror = () => reject(new Error('No se pudo leer el archivo seleccionado.'));
    lector.onload = () => {
      const img = new Image();
      img.onerror = () => reject(new Error('El archivo no es una imagen válida.'));
      img.onload = () => {
        const escala = Math.min(1, anchoMaximo / img.width);
        const ancho = Math.round(img.width * escala);
        const alto = Math.round(img.height * escala);

        const canvas = document.createElement('canvas');
        canvas.width = ancho;
        canvas.height = alto;

        const ctx = canvas.getContext('2d');
        if (!ctx) {
          resolve(lector.result as string);
          return;
        }

        ctx.drawImage(img, 0, 0, ancho, alto);
        resolve(canvas.toDataURL('image/jpeg', 0.82));
      };
      img.src = lector.result as string;
    };
    lector.readAsDataURL(archivo);
  });
}
