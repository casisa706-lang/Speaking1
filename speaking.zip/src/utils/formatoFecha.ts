/**
 * Utilidades para formatear fechas relativas en español
 * y generar iniciales de respaldo cuando un usuario no tiene imagen.
 */

/** Convierte una fecha ISO a un texto legible y conciso (ej. "Hace 5 min", "22 nov") */
export function formatearFechaRelativa(fechaIso: string): string {
  const fecha = new Date(fechaIso);
  const ahora = Date.now();
  const diferenciaSeg = Math.max(0, Math.floor((ahora - fecha.getTime()) / 1000));

  if (diferenciaSeg < 60) {
    return 'Ahora mismo';
  }

  const minutos = Math.floor(diferenciaSeg / 60);
  if (minutos < 60) {
    return `Hace ${minutos} min`;
  }

  const horas = Math.floor(minutos / 60);
  if (horas < 24) {
    return `Hace ${horas} h`;
  }

  const dias = Math.floor(horas / 24);
  if (dias < 7) {
    return dias === 1 ? 'Ayer' : `Hace ${dias} días`;
  }

  return fecha.toLocaleDateString('es-ES', {
    day: 'numeric',
    month: 'short',
  });
}

/** Obtiene hasta 2 iniciales a partir del nombre completo del usuario */
export function obtenerIniciales(nombre: string): string {
  const partes = nombre.trim().split(/\s+/).filter(Boolean);
  if (partes.length === 0) return 'SP';
  if (partes.length === 1) return partes[0].slice(0, 2).toUpperCase();
  return `${partes[0][0]}${partes[partes.length - 1][0]}`.toUpperCase();
}

/** Normaliza un identificador para mostrarlo como @usuario limpio */
export function formatearArroba(identificador: string): string {
  const limpio = identificador.trim().split('@')[0].toLowerCase().replace(/[^a-z0-9._-]/g, '');
  return `@${limpio || 'usuario'}`;
}
