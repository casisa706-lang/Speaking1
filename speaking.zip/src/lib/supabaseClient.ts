import { createClient, SupabaseClient } from '@supabase/supabase-js';

/**
 * Cliente oficial de Supabase inicializado con las variables de entorno
 * VITE_SUPABASE_URL y VITE_SUPABASE_ANON_KEY.
 *
 * Estructura recomendada para la tabla `posts` en Supabase (SQL):
 *
 * create table if not exists public.posts (
 *   id uuid default gen_random_uuid() primary key,
 *   user_id uuid references auth.users(id) on delete cascade not null,
 *   author_name text not null,
 *   author_email text not null default '',
 *   author_avatar text not null default '',
 *   author_bio text not null default '',
 *   content text not null default '',
 *   image_url text,
 *   likes jsonb not null default '[]'::jsonb,
 *   comments jsonb not null default '[]'::jsonb,
 *   created_at timestamptz not null default now()
 * );
 *
 * alter table public.posts enable row level security;
 * create policy "Lectura pública de posts" on public.posts for select using (true);
 * create policy "Crear posts autenticados" on public.posts for insert with check (auth.uid() = user_id);
 * create policy "Actualizar posts autenticados" on public.posts for update using (auth.role() = 'authenticated');
 * create policy "Eliminar propios posts" on public.posts for delete using (auth.uid() = user_id);
 */

const supabaseUrl = import.meta.env.VITE_SUPABASE_URL as string | undefined;
const supabaseAnonKey = import.meta.env.VITE_SUPABASE_ANON_KEY as string | undefined;

/** Indica si las credenciales de Supabase están presentes en el entorno */
export const estaSupabaseConfigurado = Boolean(
  supabaseUrl &&
    supabaseAnonKey &&
    supabaseUrl.startsWith('http') &&
    !supabaseUrl.includes('tu-proyecto.supabase.co')
);

/** Instancia única del cliente Supabase (null si aún no se configuran las variables) */
export const supabase: SupabaseClient | null = estaSupabaseConfigurado
  ? createClient(supabaseUrl!, supabaseAnonKey!)
  : null;
