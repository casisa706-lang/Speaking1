/**
 * Tipos de datos principales para la red social Speaking conectada a Supabase.
 */

/** Representa al usuario autenticado o al autor de una publicación */
export interface Usuario {
  id: string;
  /** Nombre completo visible en el muro y perfil */
  nombre: string;
  /** Correo electrónico registrado en Supabase Auth */
  correo: string;
  /** Ruta o URL de la foto de perfil */
  avatar: string;
  /** Descripción breve visible en el perfil */
  biografia: string;
  /** Marca de tiempo ISO de creación de la cuenta */
  creadoEn: string;
}

/** Representa un comentario almacenado dentro de una publicación en la tabla posts */
export interface Comentario {
  id: string;
  autorId: string;
  autorNombre: string;
  autorAvatar: string;
  texto: string;
  creadoEn: string;
}

/** Representa una fila mapeada de la tabla `posts` en Supabase */
export interface Publicacion {
  id: string;
  autorId: string;
  autorNombre: string;
  autorCorreo: string;
  autorAvatar: string;
  autorBiografia: string;
  contenido: string;
  /** Ruta, URL o Data URL opcional de una imagen adjunta */
  imagen?: string;
  /** Lista de IDs de usuarios que marcaron 'Me gusta' */
  meGustaIds: string[];
  /** Comentarios ordenados cronológicamente */
  comentarios: Comentario[];
  creadoEn: string;
}

/** Vistas principales disponibles tras iniciar sesión */
export type VistaActiva = 'muro' | 'perfil';

/** Resultado estándar de operaciones de autenticación con Supabase */
export interface ResultadoAuth {
  exito: boolean;
  usuario?: Usuario;
  /** Mensaje informativo cuando Supabase requiere confirmar correo antes de iniciar sesión */
  mensajeInfo?: string;
  error?: string;
}
