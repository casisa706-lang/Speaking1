import { useCallback, useEffect, useMemo, useState } from 'react';
import { BarraNavegacion } from './components/BarraNavegacion';
import { PantallaAcceso } from './components/PantallaAcceso';
import { VistaMuro } from './components/VistaMuro';
import { VistaPerfil } from './components/VistaPerfil';
import {
  actualizarPerfilSupabase,
  agregarComentarioSupabase,
  alternarMeGustaSupabase,
  cerrarSesionSupabase,
  crearPublicacionSupabase,
  eliminarComentarioSupabase,
  eliminarPublicacionSupabase,
  iniciarSesionSupabase,
  obtenerPublicacionesSupabase,
  obtenerSesionSupabase,
  registrarUsuarioSupabase,
  suscribirCambioSesion,
} from './services/supabaseSocial';
import { Publicacion, Usuario, VistaActiva } from './types/social';

/**
 * Componente raíz de Speaking.
 * Sincroniza la autenticación con Supabase Auth y el muro con la tabla `posts`.
 */
export default function App() {
  const [verificandoSesion, setVerificandoSesion] = useState(true);
  const [usuarioActual, setUsuarioActual] = useState<Usuario | null>(null);
  const [publicaciones, setPublicaciones] = useState<Publicacion[]>([]);
  const [cargandoPublicaciones, setCargandoPublicaciones] = useState(false);
  const [errorPublicaciones, setErrorPublicaciones] = useState<string | null>(null);
  const [vistaActiva, setVistaActiva] = useState<VistaActiva>('muro');
  const [perfilVistoId, setPerfilVistoId] = useState<string | null>(null);

  /** Carga todas las publicaciones desde la tabla `posts` en Supabase */
  const cargarPublicaciones = useCallback(async () => {
    setCargandoPublicaciones(true);
    setErrorPublicaciones(null);
    try {
      const lista = await obtenerPublicacionesSupabase();
      setPublicaciones(lista);
    } catch (err) {
      setErrorPublicaciones(
        err instanceof Error
          ? err.message
          : 'No se pudieron cargar las publicaciones desde Supabase.'
      );
    } finally {
      setCargandoPublicaciones(false);
    }
  }, []);

  /** Verifica la sesión inicial y suscribe cambios de autenticación en Supabase */
  useEffect(() => {
    let activo = true;

    obtenerSesionSupabase()
      .then((usuario) => {
        if (!activo) return;
        setUsuarioActual(usuario);
        if (usuario) {
          void cargarPublicaciones();
        }
      })
      .finally(() => {
        if (activo) setVerificandoSesion(false);
      });

    const cancelarSuscripcion = suscribirCambioSesion((usuario) => {
      if (!activo) return;
      setUsuarioActual(usuario);
      if (usuario) {
        void cargarPublicaciones();
      } else {
        setPublicaciones([]);
        setVistaActiva('muro');
        setPerfilVistoId(null);
      }
    });

    return () => {
      activo = false;
      cancelarSuscripcion();
    };
  }, [cargarPublicaciones]);

  /** Inicia sesión con correo y contraseña en Supabase Auth */
  const manejarIniciarSesion = async (correo: string, contrasena: string) => {
    const resultado = await iniciarSesionSupabase(correo, contrasena);
    if (resultado.exito && resultado.usuario) {
      setUsuarioActual(resultado.usuario);
      setVistaActiva('muro');
      setPerfilVistoId(null);
      await cargarPublicaciones();
    }
    return resultado;
  };

  /** Registra una nueva cuenta en Supabase Auth */
  const manejarRegistro = async (datos: {
    nombre: string;
    correo: string;
    contrasena: string;
  }) => {
    const resultado = await registrarUsuarioSupabase(datos);
    if (resultado.exito && resultado.usuario) {
      setUsuarioActual(resultado.usuario);
      setVistaActiva('muro');
      setPerfilVistoId(null);
      await cargarPublicaciones();
    }
    return resultado;
  };

  /** Cierra la sesión activa en Supabase */
  const manejarCerrarSesion = async () => {
    await cerrarSesionSupabase();
    setUsuarioActual(null);
    setPublicaciones([]);
    setVistaActiva('muro');
    setPerfilVistoId(null);
  };

  /** Inserta una nueva publicación en la tabla `posts` */
  const manejarPublicar = async (datos: { contenido: string; imagen?: string }) => {
    if (!usuarioActual) return;
    const nueva = await crearPublicacionSupabase({
      usuario: usuarioActual,
      contenido: datos.contenido,
      imagen: datos.imagen,
    });
    setPublicaciones((prev) => [nueva, ...prev]);
  };

  /** Alterna 'Me gusta' en la publicación dentro de Supabase */
  const manejarAlternarMeGusta = async (publicacionId: string) => {
    if (!usuarioActual) return;
    const actual = publicaciones.find((p) => p.id === publicacionId);
    if (!actual) return;

    const nuevosLikes = await alternarMeGustaSupabase(
      publicacionId,
      actual.meGustaIds,
      usuarioActual.id
    );

    setPublicaciones((prev) =>
      prev.map((p) => (p.id === publicacionId ? { ...p, meGustaIds: nuevosLikes } : p))
    );
  };

  /** Agrega un comentario a la publicación dentro de Supabase */
  const manejarAgregarComentario = async (publicacionId: string, texto: string) => {
    if (!usuarioActual) return;
    const actual = publicaciones.find((p) => p.id === publicacionId);
    if (!actual) return;

    const nuevosComentarios = await agregarComentarioSupabase(
      publicacionId,
      actual.comentarios,
      { autor: usuarioActual, texto }
    );

    setPublicaciones((prev) =>
      prev.map((p) =>
        p.id === publicacionId ? { ...p, comentarios: nuevosComentarios } : p
      )
    );
  };

  /** Elimina una publicación propia en Supabase */
  const manejarEliminarPublicacion = async (publicacionId: string) => {
    await eliminarPublicacionSupabase(publicacionId);
    setPublicaciones((prev) => prev.filter((p) => p.id !== publicacionId));
  };

  /** Elimina un comentario propio dentro de la tabla `posts` */
  const manejarEliminarComentario = async (
    publicacionId: string,
    comentarioId: string
  ) => {
    const actual = publicaciones.find((p) => p.id === publicacionId);
    if (!actual) return;

    const nuevosComentarios = await eliminarComentarioSupabase(
      publicacionId,
      actual.comentarios,
      comentarioId
    );

    setPublicaciones((prev) =>
      prev.map((p) =>
        p.id === publicacionId ? { ...p, comentarios: nuevosComentarios } : p
      )
    );
  };

  /** Actualiza los datos del perfil en Supabase Auth y en sus publicaciones */
  const manejarActualizarPerfil = async (datos: {
    nombre: string;
    biografia: string;
    avatar: string;
  }) => {
    if (!usuarioActual) return;
    const actualizado = await actualizarPerfilSupabase(usuarioActual.id, datos);
    setUsuarioActual(actualizado);
    setPublicaciones((prev) =>
      prev.map((p) =>
        p.autorId === actualizado.id
          ? {
              ...p,
              autorNombre: actualizado.nombre,
              autorAvatar: actualizado.avatar,
              autorBiografia: actualizado.biografia,
            }
          : p
      )
    );
  };

  /** Navega al perfil del usuario elegido */
  const abrirPerfil = (usuarioId: string) => {
    setPerfilVistoId(usuarioId);
    setVistaActiva('perfil');
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  /** Navega al muro principal */
  const irAlMuro = () => {
    setVistaActiva('muro');
    setPerfilVistoId(null);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  /** Construye el perfil del usuario consultado a partir de la sesión o de sus publicaciones */
  const usuarioDelPerfil = useMemo(() => {
    if (!usuarioActual) return null;
    const objetivoId = perfilVistoId ?? usuarioActual.id;
    if (objetivoId === usuarioActual.id) return usuarioActual;

    const publicacionDelAutor = publicaciones.find((p) => p.autorId === objetivoId);
    if (!publicacionDelAutor) return usuarioActual;

    return {
      id: publicacionDelAutor.autorId,
      nombre: publicacionDelAutor.autorNombre,
      correo: publicacionDelAutor.autorCorreo,
      avatar: publicacionDelAutor.autorAvatar,
      biografia: publicacionDelAutor.autorBiografia,
      creadoEn: publicacionDelAutor.creadoEn,
    };
  }, [usuarioActual, perfilVistoId, publicaciones]);

  if (verificandoSesion) {
    return (
      <div className="min-h-screen bg-[#0B0B0E] text-[#F4F4F6] flex items-center justify-center">
        <p className="text-sm text-[#8E8E9E]">Cargando Speaking...</p>
      </div>
    );
  }

  if (!usuarioActual || !usuarioDelPerfil) {
    return (
      <PantallaAcceso
        onIniciarSesion={manejarIniciarSesion}
        onRegistrar={manejarRegistro}
      />
    );
  }

  return (
    <div className="min-h-screen bg-[#0B0B0E] text-[#F4F4F6]">
      <BarraNavegacion
        vistaActiva={vistaActiva}
        viendoMiPerfil={usuarioDelPerfil.id === usuarioActual.id}
        onIrMuro={irAlMuro}
        onIrMiPerfil={() => abrirPerfil(usuarioActual.id)}
        onCerrarSesion={() => void manejarCerrarSesion()}
      />

      {vistaActiva === 'muro' ? (
        <VistaMuro
          usuarioActual={usuarioActual}
          publicaciones={publicaciones}
          cargandoPublicaciones={cargandoPublicaciones}
          errorPublicaciones={errorPublicaciones}
          onRecargarPublicaciones={cargarPublicaciones}
          onPublicar={manejarPublicar}
          onAlternarMeGusta={manejarAlternarMeGusta}
          onAgregarComentario={manejarAgregarComentario}
          onEliminarPublicacion={manejarEliminarPublicacion}
          onEliminarComentario={manejarEliminarComentario}
          onAbrirPerfil={abrirPerfil}
        />
      ) : (
        <VistaPerfil
          usuarioVisto={usuarioDelPerfil}
          usuarioActual={usuarioActual}
          publicaciones={publicaciones}
          onVolverMuro={irAlMuro}
          onActualizarPerfil={manejarActualizarPerfil}
          onPublicar={manejarPublicar}
          onAlternarMeGusta={manejarAlternarMeGusta}
          onAgregarComentario={manejarAgregarComentario}
          onEliminarPublicacion={manejarEliminarPublicacion}
          onEliminarComentario={manejarEliminarComentario}
          onAbrirPerfil={abrirPerfil}
        />
      )}
    </div>
  );
}
